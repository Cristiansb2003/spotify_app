export interface PlaylistMap {
    id: string
    name: string
    description: string
    images: any[]
  }
  